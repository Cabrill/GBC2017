
namespace GBC2017.DataTypes
{
	public partial class TileMapInfo
	{
		public bool HasCollision;
		public string EntityToCreate;
		public string Name;
		public System.Collections.Generic.List<FlatRedBall.Content.AnimationChain.AnimationFrameSaveBase> EmbeddedAnimation;
		
		
	}
}
