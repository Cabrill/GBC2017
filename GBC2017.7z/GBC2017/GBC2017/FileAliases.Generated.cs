namespace GBC2017
{
	public class FileAliasLogic
	{
		public static void SetFileAliases ()
		{
		}
	}
}
